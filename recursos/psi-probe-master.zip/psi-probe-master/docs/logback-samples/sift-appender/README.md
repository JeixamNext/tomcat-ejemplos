Logback Sift Appender Example

- Logback 'logback.xml' has SIFT appender example for testing psi probe SIFT appender support.  Bundle with another webapp and ran alongside psi-probe in container.